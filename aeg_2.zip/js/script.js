$(document).ready(function () {
	back_To_top();

	// Click scroll main menu
	$('.main-menu a, .wiget-reg, .block-hl-right .f-reg a').click(function (e) {
		e.preventDefault();
		var target = $(this).attr('href');
		if ($(target).length) {
			$('html, body').animate({
				scrollTop: $(target).offset().top - 77
			}, 1000);
		}
	});

	// Mobile menu
	$('.b-menu-mobile li:not(.f-phone) a').click(function (e) {
		e.preventDefault();
		$('.b-menu-mobile .bt-close').click();
		var target = $(this).attr('href');
		if ($(target).length) {
			$('html, body').animate({
				scrollTop: $(target).offset().top - 77
			}, 1000);
		}
	});

	$('.dl-trigger').click(function (e) {
		$('.b-menu-mobile').addClass("show");
	});

	$('.b-menu-mobile .bt-close').click(function (e) {
		$('.b-menu-mobile').removeClass("show");
	});

	$('.popup-thanks .bt-close').click(function (e) {
		$('.popup-thanks').hide();
	});

	// Slide home
	$('.slide-home.owl-carousel').owlCarousel({
		animateOut: 'fadeOut',
		mouseDrag: false,
		items: 1,
		loop: true,
		nav: true,
		dots: false,
		autoplay: true,
		autoplayTimeout: 5000,
		autoplayHoverPause: false,
		smartSpeed: 600,
	});

	// Change tab
	$('.propram-tabs').each(function (e) {
		$(this).find('.nav-content a').click(function (e) {
			e.preventDefault();
		});
		$(this).find('li').click(function (event) {
			var _this = $(this);
			event.preventDefault();
			$(this).find('a').focus();
			if (!_this.hasClass("active")) {
				_this
					.siblings(".active").removeClass("active").end()
					.addClass("active");
				var relatedTabContentID = _this.find("a").attr('href');
				$(relatedTabContentID).siblings().removeClass('active').end().addClass('active');
			}
		});
	});

	// Back to top
	function back_To_top() {
		window.onscroll = function () { scrollFunction() };

		function scrollFunction() {
			if ($(window).scrollTop() > 20) {
				$('.back-to-top').addClass('show');
			} else {
				$('.back-to-top').removeClass('show');
			}
		}

		$('.back-to-top').click(function () {
			$('html, body').animate({ scrollTop: 0 }, 1000);
		});
	}

	// Register validate
	$("form.form-register").validate({
		rules: {
			"NAME": {
				required: true,
				maxlength: 15
			},
			"PHONE": {
				required: true,
				number: true,
				minlength: 7,
				maxlength: 15
			},
			"AGE": {
				required: true,
				number: true,
				minlength: 1,
				maxlength: 2
			},
			"DISTRICT": {
				required: true,
			}
		},
		// Specify validation error messages
		messages: {
			"NAME": "Vui lòng nhập họ tên phụ huynh",
			"PHONE": "Vui lòng nhập số điện thoại phụ huynh (7-15 số)",
			"AGE": "Vui lòng nhập số tuổi của bé",
			"DISTRICT": "Vui lòng chọn địa điểm"
		},

		submitHandler: function (form) {
			$('body').css("overflow", "hidden");
			$('.form-register .bt-submit').addClass('off');
			$('.popup-thanks').show();

			// Submit to google form
			$("#NAME_go").val($('input[name="NAME"]').val());
			$("#PHONE_go").val($('input[name="PHONE"]').val());
			$("#AGE_go").val($('input[name="AGE"]').val());
			$("#DISTRICT_go").val($('select[name="DISTRICT"] option:selected').val());

			$.ajax({
				type: 'POST',
				url: $('.form-go').attr("action"),
				data: $('.form-go').serialize(),
				success: function (response) { },
			});

			setTimeout(() => {
				location.reload();
			}, 5000);
		}
	});

});